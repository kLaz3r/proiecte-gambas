# Gambas Horoscope
Just a simple college app to fetch data from an external API and display it in the GUI
