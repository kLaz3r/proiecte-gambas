# Horoscope App Written in Gambas

This is a college project.